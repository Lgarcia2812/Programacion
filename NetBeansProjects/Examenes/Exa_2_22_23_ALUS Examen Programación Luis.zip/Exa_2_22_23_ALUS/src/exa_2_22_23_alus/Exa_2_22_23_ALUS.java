/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exa_2_22_23_alus;

import java.util.Scanner;


public class Exa_2_22_23_ALUS {
    
    enum  Level{CARISIMO, CARO, NORMAL, BARATO, OFERTON}
    
    static Scanner teclado = new Scanner(System.in);
       
    public static void main(String[] args) {

        sacaValores();
        restaurante();
        pideNumMesas();
        pideComensales();
    }
    
//     1 pto
//     sacaValores
    
    public static void sacaValores(){
    Level precioRestaurante = null;
        
    System.out.println("Indique como te ha parecido el precio (CARISIMO, CARO, NORMAL, BARATO, OFERTON)");
        try{
            precioRestaurante = Level.valueOf(teclado.nextLine().toUpperCase());
        } catch (IllegalArgumentException error){
            System.out.println("No renozco ese nivel, porfavor ejecute el programa"
                    + "de nuevo y introduce un valor correspondiente");
            
        }
        
             
        switch (precioRestaurante){
            case CARISIMO: System.out.println("El restaurante tendrá en cuenta tu opinion");
                    break;
            case CARO: System.out.println("El restaurante tendrá en cuenta tu opinion");
                    break;
            case NORMAL: System.out.println("Gracias por tu valoracion");
                    break;
            case BARATO: System.out.println("Me alegra que le haya parecido barato");
                    break;
            case OFERTON: System.out.println("Me alegra que le haya parecido una buena oferta");
                    break;
             
        }
        
        System.out.println("El precio del restaurante segun tu opinion es" + precioRestaurante);
        
        for (Level nivel : Level.values()){
               
        } 
        
                   
    }
    
    public static int pideNumMesas(){
        
        int mesas;
        System.out.println("Introduce las mesas"); 
        mesas = teclado.nextInt();
        while (mesas < 2 || mesas > 50){
            System.out.println("Esas mesas no se encuentra en nuestro rango, "
                    + "Prueba de nuevo."); 
            mesas = teclado.nextInt();
        }
        return mesas;
    }
    
    public static int pideComensales(){
        
        int comensales;
        System.out.println("Introduce el numero de comensales"); 
        comensales = teclado.nextInt();
        while (comensales < 0 || comensales > 4){
            System.out.println("Tantos comensales no se puede prueba de nuevo"); 
            comensales = teclado.nextInt();
        }
        return comensales;
    }
             
             
    public static void restaurante(){
        int numMesas = pideNumMesas();
//        int[] mesas = generaMesas(numMesas);
//        System.out.println(Arrays.toString(mesas));
//        byte comensales = pidecomensales();
//        int numMesa = asignaMesa (mesas, comensales);
//        if (numMesa != -1) System.out.printf("Mesa número %d asignada. ", numMesa);
//        else System.out.println("Lo sentimos, no hemos encontrado mesa");
    }
    
    
     
    
    // 1.5 ptos
// pideNumMesas
    
    // 1.5 ptos
//generaMesas
    
    // 2 ptos
//pidecomensales
    
    // 4 ptos
//asignaMesa
}
