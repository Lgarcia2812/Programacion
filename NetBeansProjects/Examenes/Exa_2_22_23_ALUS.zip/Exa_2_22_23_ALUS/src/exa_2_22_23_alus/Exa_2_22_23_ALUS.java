/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exa_2_22_23_alus;


public class Exa_2_22_23_ALUS {
    
       
    public static void main(String[] args) {

        sacaValores();
        restaurante();
 

    }
    
    // 1 pto
//     sacaValores
             
             
    public static void restaurante(){
        int numMesas = pideNumMesas();
        int[] mesas = generaMesas(numMesas);
        System.out.println(Arrays.toString(mesas));
        byte comensales = pidecomensales();
        int numMesa = asignaMesa (mesas, comensales);
        if (numMesa != -1) System.out.printf("Mesa número %d asignada. ", numMesa);
        else System.out.println("Lo sentimos, no hemos encontrado mesa");
    }
    
    // 1.5 ptos
// pideNumMesas
    
    // 1.5 ptos
//generaMesas
    
    // 2 ptos
//pidecomensales
    
    // 4 ptos
//asignaMesa
}
